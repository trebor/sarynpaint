Last updated 16 August 2009 by Robert Harris, sarynpaint@trebor.org.

SarynPaint is a simple paint program written for my dear friend Saryn.
It is hoped that others might extend the functionality of this program.

Requirements:

- Java 1.5 or later

-------------------------------------------------------------------------------

Copyright (C) 2009 Robert B. Harris (sarynpaint@trebor.org)

This file is part of SarynPaint

SarynPaint is free software: you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, either version 3 of the License, or (at your
option) any later version.

Saryn is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with SarynPaint.  If not, see <http://www.gnu.org/licenses/>.
